(function () {
  "use strict";

  const CONFIG_KEY = "beautifulNewtabConfig";

  const DEFAULT_CONFIG = {
    settings: {
      backgroundImage: "",
      backgroundFit: "cover",
      backgroundBlur: 0,
      backgroundBrightness: 1,
      defaultIconSize: 64,
      autoAlign: true,
      gridSize: 112,
      searchEngine: "bing",
      theme: "dark",
      username: "",
      displayMode: "both",
      searchBarWidth: 760,
      sidebarCollapsed: true,
      headerPosition: 50
    },
    items: [
      {
        id: "site_example",
        type: "site",
        title: "Example",
        url: "https://example.com",
        icon: "",
        x: 0,
        y: 0,
        size: 64,
        folderId: null
      },
      {
        id: "site_github",
        type: "site",
        title: "GitHub",
        url: "https://github.com",
        icon: "",
        x: 112,
        y: 0,
        size: 64,
        folderId: null
      },
      {
        id: "folder_study",
        type: "folder",
        title: "学习",
        x: 224,
        y: 0,
        size: 64,
        children: []
      }
    ]
  };

  const hasChromeStorage = Boolean(
    window.chrome &&
      chrome.storage &&
      chrome.storage.local &&
      typeof chrome.storage.local.get === "function"
  );

  /** Creates a deep clone for config objects so callers can mutate safely. */
  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  /** Generates a stable-enough item id for local user-created records. */
  function createId(prefix) {
    const randomPart = Math.random().toString(36).slice(2, 9);
    return `${prefix}_${Date.now().toString(36)}_${randomPart}`;
  }

  /** Normalizes a URL for opening and favicon extraction. */
  function normalizeUrl(url) {
    const trimmed = String(url || "").trim();
    if (!trimmed) return "";
    if (/^[a-z][a-z\d+\-.]*:\/\//i.test(trimmed)) return trimmed;
    return `https://${trimmed}`;
  }

  /** Returns a hostname when the supplied value is a usable URL. */
  function getHostname(url) {
    try {
      return new URL(normalizeUrl(url)).hostname;
    } catch (error) {
      return "";
    }
  }

  /** Builds a public favicon URL used when the user has not supplied an icon. */
  function faviconFor(url) {
    const domain = getHostname(url);
    if (!domain) return "";
    return `https://www.google.com/s2/favicons?domain=${encodeURIComponent(domain)}&sz=128`;
  }

  /** Ensures numeric settings stay inside supported first-version values. */
  function normalizeSettings(settings) {
    const merged = Object.assign({}, DEFAULT_CONFIG.settings, settings || {});
    const size = Number(merged.defaultIconSize);
    const gridSize = Number(merged.gridSize);
    const blur = Number(merged.backgroundBlur);
    const brightness = Number(merged.backgroundBrightness);

    merged.defaultIconSize = [36, 48, 56, 64, 65, 72, 80, 96].includes(size) ? size : 64;
    merged.gridSize = [72, 88, 96, 112].includes(gridSize) ? gridSize : 112;
    merged.backgroundBlur = Number.isFinite(blur) ? Math.min(Math.max(blur, 0), 20) : 0;
    merged.backgroundBrightness = Number.isFinite(brightness)
      ? Math.min(Math.max(brightness, 0.35), 1.4)
      : 1;
    merged.backgroundFit = ["cover", "contain", "repeat"].includes(merged.backgroundFit)
      ? merged.backgroundFit
      : "cover";
    merged.autoAlign = Boolean(merged.autoAlign);
    merged.searchEngine = ["bing", "google", "baidu"].includes(merged.searchEngine)
      ? merged.searchEngine
      : "bing";
    merged.backgroundImage = typeof merged.backgroundImage === "string" ? merged.backgroundImage : "";
    merged.theme = ["dark", "light"].includes(merged.theme) ? merged.theme : "dark";
    merged.username = typeof merged.username === "string" ? merged.username.slice(0, 30) : "";
    merged.displayMode = ["clock", "greeting", "both", "alternate"].includes(merged.displayMode) ? merged.displayMode : "both";
    merged.searchBarWidth = Number.isFinite(Number(merged.searchBarWidth))
      ? Math.min(Math.max(Number(merged.searchBarWidth), 360), 760)
      : 760;
    merged.sidebarCollapsed = Boolean(merged.sidebarCollapsed);
    merged.headerPosition = Number.isFinite(Number(merged.headerPosition))
      ? Math.min(Math.max(Number(merged.headerPosition), 10), 90)
      : 50;
    return merged;
  }

  /** Normalizes one imported or persisted site/folder item. */
  function normalizeItem(raw, index, settings) {
    if (!raw || typeof raw !== "object") return null;
    const type = raw.type === "folder" ? "folder" : raw.type === "site" ? "site" : "";
    if (!type) return null;
    const fallbackId = createId(type);
    const item = {
      id: typeof raw.id === "string" && raw.id ? raw.id : fallbackId,
      type,
      title: String(raw.title || (type === "folder" ? "新文件夹" : "新网站")).slice(0, 40),
      x: Math.max(0, Number.isFinite(Number(raw.x)) ? Number(raw.x) : index * settings.gridSize),
      y: Math.max(0, Number.isFinite(Number(raw.y)) ? Number(raw.y) : 0),
      size: [36, 48, 56, 64, 65, 72, 80, 96].includes(Number(raw.size)) ? Number(raw.size) : settings.defaultIconSize
    };

    if (type === "site") {
      item.url = normalizeUrl(raw.url || "");
      item.icon = typeof raw.icon === "string" ? raw.icon : "";
      item.folderId = typeof raw.folderId === "string" ? raw.folderId : null;
    } else {
      item.children = Array.isArray(raw.children)
        ? raw.children.filter((id) => typeof id === "string")
        : [];
    }

    return item;
  }

  /** Removes broken folder references and duplicate child ids after import/load. */
  function reconcileFolders(config) {
    const ids = new Set(config.items.map((item) => item.id));
    const folderIds = new Set(config.items.filter((item) => item.type === "folder").map((item) => item.id));
    const claimedChildren = new Set();

    config.items.forEach((item) => {
      if (item.type !== "folder") return;
      const uniqueChildren = [];
      item.children.forEach((childId) => {
        if (ids.has(childId) && !claimedChildren.has(childId)) {
          uniqueChildren.push(childId);
          claimedChildren.add(childId);
        }
      });
      item.children = uniqueChildren;
    });

    config.items.forEach((item) => {
      if (item.type !== "site") return;
      if (!item.folderId || !folderIds.has(item.folderId)) {
        item.folderId = null;
        return;
      }
      if (!claimedChildren.has(item.id)) {
        const folder = config.items.find((candidate) => candidate.id === item.folderId);
        if (folder) folder.children.push(item.id);
      }
    });
  }

  /** Converts arbitrary persisted data into the supported v1 config shape. */
  function normalizeConfig(rawConfig) {
    const settings = normalizeSettings(rawConfig && rawConfig.settings);
    const rawItems = Array.isArray(rawConfig && rawConfig.items) ? rawConfig.items : DEFAULT_CONFIG.items;
    const seen = new Set();
    const items = rawItems
      .map((item, index) => normalizeItem(item, index, settings))
      .filter(Boolean)
      .map((item) => {
        if (seen.has(item.id)) item.id = createId(item.type);
        seen.add(item.id);
        return item;
      });

    const config = { settings, items };
    reconcileFolders(config);
    return config;
  }

  /** Loads config from chrome.storage.local, falling back to localStorage for browser testing. */
  function loadConfig() {
    if (hasChromeStorage) {
      return new Promise((resolve) => {
        chrome.storage.local.get(CONFIG_KEY, (result) => {
          resolve(normalizeConfig(result && result[CONFIG_KEY]));
        });
      });
    }

    try {
      const raw = window.localStorage.getItem(CONFIG_KEY);
      return Promise.resolve(normalizeConfig(raw ? JSON.parse(raw) : null));
    } catch (error) {
      return Promise.resolve(normalizeConfig(null));
    }
  }

  /** Saves the full config to browser-local storage. */
  function saveConfig(config) {
    const normalized = normalizeConfig(config);
    if (hasChromeStorage) {
      return new Promise((resolve, reject) => {
        chrome.storage.local.set({ [CONFIG_KEY]: normalized }, () => {
          const error = chrome.runtime && chrome.runtime.lastError;
          if (error) {
            reject(new Error(error.message));
            return;
          }
          resolve(normalized);
        });
      });
    }

    window.localStorage.setItem(CONFIG_KEY, JSON.stringify(normalized));
    return Promise.resolve(normalized);
  }

  /** Reads a File object as a data URL. */
  function readFileAsDataUrl(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ""));
      reader.onerror = () => reject(reader.error || new Error("读取文件失败"));
      reader.readAsDataURL(file);
    });
  }

  /** Compresses an uploaded image to reduce local storage pressure. */
  async function compressImageFile(file, options) {
    const dataUrl = await readFileAsDataUrl(file);
    const maxWidth = (options && options.maxWidth) || 1920;
    const maxHeight = (options && options.maxHeight) || 1080;
    const quality = (options && options.quality) || 0.86;
    const outputType = (options && options.type) || "image/jpeg";

    return new Promise((resolve) => {
      const image = new Image();
      image.onload = () => {
        const ratio = Math.min(maxWidth / image.width, maxHeight / image.height, 1);
        const width = Math.max(1, Math.round(image.width * ratio));
        const height = Math.max(1, Math.round(image.height * ratio));
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (outputType === "image/jpeg") {
          ctx.fillStyle = "#ffffff";
          ctx.fillRect(0, 0, width, height);
        }
        ctx.drawImage(image, 0, 0, width, height);
        resolve(canvas.toDataURL(outputType, quality));
      };
      image.onerror = () => resolve(dataUrl);
      image.src = dataUrl;
    });
  }

  /** Downloads the current config as a JSON file. */
  function exportConfig(config) {
    const blob = new Blob([JSON.stringify(normalizeConfig(config), null, 2)], {
      type: "application/json"
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `beautiful-newtab-config-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  }

  /** Parses and validates an imported config JSON file. */
  async function importConfigFile(file) {
    const text = await file.text();
    const parsed = JSON.parse(text);
    return normalizeConfig(parsed);
  }

  window.NewtabStorage = {
    CONFIG_KEY,
    DEFAULT_CONFIG,
    clone,
    createId,
    normalizeUrl,
    getHostname,
    faviconFor,
    normalizeConfig,
    loadConfig,
    saveConfig,
    compressImageFile,
    exportConfig,
    importConfigFile
  };
})();
