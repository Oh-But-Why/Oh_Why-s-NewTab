(function () {
  "use strict";

  let api = null;
  let elements = null;

  const ENGINE_LABELS = {
    bing: "Bing",
    google: "Google",
    baidu: "Baidu"
  };

  /** Initializes all settings drawer controls. */
  function init(appApi, refs) {
    api = appApi;
    elements = refs;

    elements.settingsButton.addEventListener("click", togglePanel);
    elements.closeSettings.addEventListener("click", closePanel);

    /* New: theme toggle */
    elements.themeToggle.addEventListener("change", () => {
      const isDark = elements.themeToggle.checked;
      updateSetting("theme", isDark ? "dark" : "light", { renderDesktop: false });
      applyTheme(isDark ? "dark" : "light");
    });

    /* New: username */
    elements.usernameInput.addEventListener("input", () => {
      const value = elements.usernameInput.value.trim().slice(0, 30);
      updateSetting("username", value, { renderDesktop: false });
      api.updateGreeting();
    });

    /* New: display mode */
    elements.displayMode.addEventListener("change", () => {
      updateSetting("displayMode", elements.displayMode.value, { renderDesktop: false });
      api.applyDisplayMode(elements.displayMode.value);
    });

    /* Search bar width */
    const searchBarWidthInput = elements.searchBarWidth;
    const searchBarWidthValue = elements.searchBarWidthValue;
    searchBarWidthInput.addEventListener("input", () => {
      const val = Number(searchBarWidthInput.value);
      searchBarWidthValue.textContent = String(val);
      document.documentElement.style.setProperty("--search-bar-width", `${val}px`);
      updateSetting("searchBarWidth", val, { renderDesktop: false });
    });

    /* Header position */
    const headerPositionInput = elements.headerPosition;
    const headerPositionValue = elements.headerPositionValue;
    headerPositionInput.addEventListener("input", () => {
      const val = Number(headerPositionInput.value);
      headerPositionValue.textContent = String(val);
      updateSetting("headerPosition", val, { renderDesktop: false });
      api.applyHeaderPosition(val);
    });

    /* Background */
    elements.backgroundInput.addEventListener("change", onBackgroundUpload);
    elements.backgroundFit.addEventListener("change", () => updateSetting("backgroundFit", elements.backgroundFit.value));
    elements.backgroundBlur.addEventListener("input", () => {
      updateSetting("backgroundBlur", Number(elements.backgroundBlur.value), { renderDesktop: false });
    });
    elements.backgroundBrightness.addEventListener("input", () => {
      updateSetting("backgroundBrightness", Number(elements.backgroundBrightness.value), { renderDesktop: false });
    });

    /* Shortcuts */
    elements.defaultIconSize.addEventListener("change", () => {
      updateDefaultIconSize(Number(elements.defaultIconSize.value));
    });
    elements.gridSize.addEventListener("change", () => {
      updateSetting("gridSize", Number(elements.gridSize.value));
      api.normalizeLayout();
    });
    elements.searchEngine.addEventListener("change", () => {
      updateSetting("searchEngine", elements.searchEngine.value, { renderDesktop: false });
    });
    elements.autoAlign.addEventListener("change", () => {
      updateSetting("autoAlign", elements.autoAlign.checked);
      if (elements.autoAlign.checked) api.normalizeLayout();
    });

    elements.addSiteButton.addEventListener("click", () => api.openSiteDialog());
    elements.createFolderButton.addEventListener("click", () => NewtabFolder.createFolder("新文件夹"));
    elements.exportButton.addEventListener("click", () => NewtabStorage.exportConfig(api.getConfig()));
    elements.importInput.addEventListener("change", onImportConfig);
  }

  /** Shows the settings drawer. */
  function openPanel() {
    elements.settingsPanel.classList.add("open");
    elements.settingsPanel.setAttribute("aria-hidden", "false");
  }

  /** Hides the settings drawer. */
  function closePanel() {
    elements.settingsPanel.classList.remove("open");
    elements.settingsPanel.setAttribute("aria-hidden", "true");
  }

  /** Toggles the settings drawer from the floating gear button. */
  function togglePanel() {
    if (elements.settingsPanel.classList.contains("open")) {
      closePanel();
    } else {
      openPanel();
    }
  }

  /** Updates one setting, applies it to the UI, and persists the full config. */
  function updateSetting(key, value, options) {
    api.updateConfig((config) => {
      config.settings[key] = value;
    });
    applyValues(api.getConfig().settings);
    api.applySettings();
    if (!options || options.renderDesktop !== false) api.renderDesktop();
  }

  /** Updates the default icon size and applies it to items still using the old default. */
  function updateDefaultIconSize(nextSize) {
    const previousSize = api.getConfig().settings.defaultIconSize;
    api.updateConfig((config) => {
      config.settings.defaultIconSize = nextSize;
      config.items.forEach((item) => {
        const currentSize = Number(item.size);
        if (!currentSize || currentSize === previousSize) {
          item.size = nextSize;
        }
      });
    });
    applyValues(api.getConfig().settings);
    api.renderDesktop();
    api.showToast("图标大小已更新");
  }

  /** Reflects current settings in the settings drawer controls. */
  function applyValues(settings) {
    elements.backgroundFit.value = settings.backgroundFit;
    elements.backgroundBlur.value = String(settings.backgroundBlur);
    elements.backgroundBrightness.value = String(settings.backgroundBrightness);
    elements.blurValue.value = String(settings.backgroundBlur);
    elements.brightnessValue.value = Number(settings.backgroundBrightness).toFixed(2);
    elements.defaultIconSize.value = String(settings.defaultIconSize);
    elements.gridSize.value = String(settings.gridSize);
    elements.searchEngine.value = settings.searchEngine;
    elements.autoAlign.checked = settings.autoAlign;
    elements.searchEngineButton.textContent = ENGINE_LABELS[settings.searchEngine] || "Bing";

    /* New fields */
    elements.themeToggle.checked = settings.theme === "dark";
    elements.usernameInput.value = settings.username || "";
    elements.displayMode.value = settings.displayMode;
    elements.searchBarWidth.value = String(settings.searchBarWidth);
    elements.searchBarWidthValue.textContent = String(settings.searchBarWidth);
    document.documentElement.style.setProperty("--search-bar-width", `${settings.searchBarWidth}px`);
    if (elements.headerPosition) {
      elements.headerPosition.value = String(settings.headerPosition);
      elements.headerPositionValue.textContent = String(settings.headerPosition);
    }
  }

  /** Applies theme class to body element. */
  function applyTheme(theme) {
    if (theme === "light") {
      document.body.classList.add("light-theme");
    } else {
      document.body.classList.remove("light-theme");
    }
  }

  /** Uploads and compresses a background image before storing it locally. */
  async function onBackgroundUpload(event) {
    const file = event.target.files && event.target.files[0];
    if (!file) return;
    try {
      api.showToast("正在处理背景图...");
      const dataUrl = await NewtabStorage.compressImageFile(file, {
        maxWidth: 1920,
        maxHeight: 1080,
        quality: 0.86
      });
      updateSetting("backgroundImage", dataUrl, { renderDesktop: false });
      api.showToast("背景已保存");
    } catch (error) {
      api.showToast("背景保存失败");
    } finally {
      event.target.value = "";
    }
  }

  /** Imports a JSON config file, replaces current config, and rerenders the app. */
  async function onImportConfig(event) {
    const file = event.target.files && event.target.files[0];
    if (!file) return;
    try {
      const imported = await NewtabStorage.importConfigFile(file);
      await api.replaceConfig(imported);
      applyValues(api.getConfig().settings);
      applyTheme(api.getConfig().settings.theme);
      api.applySettings();
      api.normalizeLayout();
      api.renderDesktop();
      api.applyDisplayMode(api.getConfig().settings.displayMode);
      api.updateGreeting();
      api.showToast("配置已导入");
    } catch (error) {
      api.showToast("导入失败，请检查 JSON 文件");
    } finally {
      event.target.value = "";
    }
  }

  /** Cycles the selected search engine from the search-bar chip. */
  function cycleSearchEngine() {
    const order = ["bing", "google", "baidu"];
    const settings = api.getConfig().settings;
    const index = order.indexOf(settings.searchEngine);
    const next = order[(index + 1) % order.length];
    updateSetting("searchEngine", next, { renderDesktop: false });
    api.showToast(`搜索引擎：${ENGINE_LABELS[next]}`);
  }

  window.NewtabSettings = {
    init,
    applyValues,
    applyTheme,
    openPanel,
    closePanel,
    cycleSearchEngine
  };
})();
