(function () {
  "use strict";

  /* ── Constants ─────────────────────────────────────────── */

  const SEARCH_URLS = {
    bing: "https://www.bing.com/search?q=",
    google: "https://www.google.com/search?q=",
    baidu: "https://www.baidu.com/s?wd="
  };

  const ENGINE_LABELS = {
    bing: "Bing",
    google: "Google",
    baidu: "Baidu"
  };

  /* Multi-language greetings with rotating phrases */
  const GREETINGS = [
    { lang: "en", phrases: ["Hello, {name}", "Welcome back, {name}", "Good to see you, {name}"] },
    { lang: "zh", phrases: ["你好，{name}", "欢迎回来，{name}", "很高兴见到你，{name}"] },
    { lang: "ja", phrases: ["こんにちは、{name}", "お帰りなさい、{name}"] },
    { lang: "ko", phrases: ["안녕하세요, {name}", "다시 오신 것을 환영합니다, {name}"] },
    { lang: "fr", phrases: ["Bonjour, {name}", "Content de vous revoir, {name}"] },
    { lang: "es", phrases: ["¡Hola, {name}!", "Bienvenido de nuevo, {name}"] }
  ];

  /* Fun quotes for easter egg */
  const FUN_QUOTES = [
    "🎉 你发现了隐藏彩蛋！",
    "🌟 生活就像浏览器，总有新的标签页等着你。",
    "🚀 探索未知，从这里开始。",
    "💎 每一个新标签都是一次新的冒险。",
    "🌈 代码改变世界，你改变每一天。",
    "🎨 创造力是你最好的书签。",
    "🔥 You're awesome! Keep browsing!",
    "🦄 独角兽在后台默默为你工作..."
  ];

  /* Background color palettes for shuffle */
  const BG_PALETTES = [
    { name: "Deep Space", colors: ["#08080f", "#0d0d1a"], accent: "rgba(91,156,245,0.12)" },
    { name: "Midnight Blue", colors: ["#0a0a1a", "#0f1030"], accent: "rgba(99,102,241,0.15)" },
    { name: "Forest Night", colors: ["#0a0f08", "#101a0d"], accent: "rgba(52,211,153,0.12)" },
    { name: "Wine Dark", colors: ["#0f0808", "#1a0d12"], accent: "rgba(245,101,135,0.12)" },
    { name: "Deep Purple", colors: ["#0c0812", "#181025"], accent: "rgba(167,139,250,0.12)" },
    { name: "Ocean Deep", colors: ["#080f14", "#0d1822"], accent: "rgba(56,189,248,0.12)" },
    { name: "Pure Dark", colors: ["#050508", "#0a0a10"], accent: "rgba(255,255,255,0.04)" },
    { name: "Sunset Dark", colors: ["#0f0a08", "#1a1010"], accent: "rgba(251,146,60,0.1)" }
  ];

  /* ── State ────────────────────────────────────────────── */

  let config = null;
  let refs = null;
  let pendingSiteIcon = "";
  let toastTimer = 0;
  let saveTimer = 0;
  let clockTimer = 0;
  let alternateTimer = 0;
  let greetingIndex = 0;
  let phraseIndex = 0;
  let brandClickCount = 0;
  let brandClickTimer = 0;
  let currentBgPalette = 0;

  /* Konami code tracking */
  const KONAMI_CODE = [
    "ArrowUp", "ArrowUp", "ArrowDown", "ArrowDown",
    "ArrowLeft", "ArrowRight", "ArrowLeft", "ArrowRight",
    "KeyB", "KeyA"
  ];
  let konamiIndex = 0;

  /* ── DOM refs ─────────────────────────────────────────── */

  function getRefs() {
    const base = {
      backgroundLayer: document.getElementById("backgroundLayer"),
      desktop: document.getElementById("desktop"),
      searchForm: document.getElementById("searchForm"),
      searchInput: document.getElementById("searchInput"),
      searchEngineButton: document.getElementById("searchEngineButton"),
      settingsButton: document.getElementById("settingsButton"),
      settingsPanel: document.getElementById("settingsPanel"),
      closeSettings: document.getElementById("closeSettings"),
      backgroundInput: document.getElementById("backgroundInput"),
      backgroundFit: document.getElementById("backgroundFit"),
      backgroundBlur: document.getElementById("backgroundBlur"),
      backgroundBrightness: document.getElementById("backgroundBrightness"),
      blurValue: document.getElementById("blurValue"),
      brightnessValue: document.getElementById("brightnessValue"),
      addSiteButton: document.getElementById("addSiteButton"),
      createFolderButton: document.getElementById("createFolderButton"),
      defaultIconSize: document.getElementById("defaultIconSize"),
      gridSize: document.getElementById("gridSize"),
      searchEngine: document.getElementById("searchEngine"),
      autoAlign: document.getElementById("autoAlign"),
      exportButton: document.getElementById("exportButton"),
      importInput: document.getElementById("importInput"),
      modalBackdrop: document.getElementById("modalBackdrop"),
      folderModal: document.getElementById("folderModal"),
      folderTitleInput: document.getElementById("folderTitleInput"),
      folderItems: document.getElementById("folderItems"),
      deleteFolderButton: document.getElementById("deleteFolderButton"),
      closeFolderButton: document.getElementById("closeFolderButton"),
      siteDialog: document.getElementById("siteDialog"),
      siteForm: document.getElementById("siteForm"),
      siteDialogTitle: document.getElementById("siteDialogTitle"),
      editingSiteId: document.getElementById("editingSiteId"),
      siteTitle: document.getElementById("siteTitle"),
      siteUrl: document.getElementById("siteUrl"),
      siteIconInput: document.getElementById("siteIconInput"),
      siteSize: document.getElementById("siteSize"),
      siteIconPreview: document.getElementById("siteIconPreview"),
      deleteSiteButton: document.getElementById("deleteSiteButton"),
      cancelSiteButton: document.getElementById("cancelSiteButton"),
      toast: document.getElementById("toast"),
      confettiCanvas: document.getElementById("confettiCanvas"),
      newtabShell: document.querySelector(".newtab-shell"),

      /* New elements */
      sidebar: document.getElementById("sidebar"),
      sidebarToggle: document.getElementById("sidebarToggle"),
      sidebarThemeToggle: document.getElementById("sidebarThemeToggle"),
      sidebarSettingsBtn: document.getElementById("sidebarSettingsBtn"),
      sidebarShuffleBg: document.getElementById("sidebarShuffleBg"),
      sidebarAbout: document.getElementById("sidebarAbout"),
      headerSection: document.getElementById("headerSection"),
      clockDisplay: document.getElementById("clockDisplay"),
      timeText: document.getElementById("timeText"),
      dateText: document.getElementById("dateText"),
      greetingDisplay: document.getElementById("greetingDisplay"),
      greetingText: document.getElementById("greetingText"),
      searchBarWidth: document.getElementById("searchBarWidth"),
      searchBarWidthValue: document.getElementById("searchBarWidthValue"),
      themeToggle: document.getElementById("themeToggle"),
      usernameInput: document.getElementById("usernameInput"),
      displayMode: document.getElementById("displayMode"),
      headerPosition: document.getElementById("headerPosition"),
      headerPositionValue: document.getElementById("headerPositionValue"),
      authorCard: document.getElementById("authorCard"),
      brandIcon: document.querySelector(".brand-icon")
    };

    return base;
  }

  /* ── Config accessors ─────────────────────────────────── */

  function getConfig() { return config; }
  function findItem(id) { return config.items.find((item) => item.id === id) || null; }
  function getDesktopItems() {
    return config.items.filter((item) => item.type === "folder" || (item.type === "site" && !item.folderId));
  }

  function scheduleSave() {
    window.clearTimeout(saveTimer);
    saveTimer = window.setTimeout(async () => {
      try { config = await NewtabStorage.saveConfig(config); }
      catch (error) { showToast("保存失败，图片可能过大"); }
    }, 120);
  }

  function updateConfig(mutator) {
    mutator(config);
    config = NewtabStorage.normalizeConfig(config);
    scheduleSave();
  }

  async function replaceConfig(nextConfig) {
    config = NewtabStorage.normalizeConfig(nextConfig);
    config = await NewtabStorage.saveConfig(config);
  }

  /* ── Theme ─────────────────────────────────────────────── */

  function applyThemeFromSettings() {
    const theme = config.settings.theme;
    if (theme === "light") {
      document.body.classList.add("light-theme");
    } else {
      document.body.classList.remove("light-theme");
    }
    if (refs && refs.themeToggle) {
      refs.themeToggle.checked = theme === "dark";
    }
  }

  function toggleTheme() {
    const next = config.settings.theme === "dark" ? "light" : "dark";
    updateConfig((c) => { c.settings.theme = next; });
    applyThemeFromSettings();
    NewtabSettings.applyValues(config.settings);
    showToast(next === "dark" ? "🌙 已切换为深色主题" : "☀️ 已切换为浅色主题");
  }

  /* ── Background Shuffle ───────────────────────────────── */

  function shuffleBackground() {
    currentBgPalette = (currentBgPalette + 1) % BG_PALETTES.length;
    const palette = BG_PALETTES[currentBgPalette];
    const layer = refs.backgroundLayer;
    if (!config.settings.backgroundImage) {
      layer.style.backgroundImage = `
        radial-gradient(ellipse at 40% 20%, ${palette.accent}, transparent 50%),
        linear-gradient(180deg, ${palette.colors[0]} 0%, ${palette.colors[1]} 100%)
      `;
    }
    showToast(`🎨 色调：${palette.name}`);
  }

  /* ── Settings Application ─────────────────────────────── */

  function applySettings() {
    const settings = config.settings;
    document.documentElement.style.setProperty("--grid-size", `${settings.gridSize}px`);
    document.documentElement.style.setProperty("--search-bar-width", `${settings.searchBarWidth}px`);
    refs.desktop.style.setProperty("--grid-size", `${settings.gridSize}px`);
    refs.backgroundLayer.style.backgroundSize = settings.backgroundFit === "repeat" ? "auto" : settings.backgroundFit;
    refs.backgroundLayer.style.backgroundRepeat = settings.backgroundFit === "repeat" ? "repeat" : "no-repeat";
    refs.backgroundLayer.style.filter = `brightness(${settings.backgroundBrightness}) blur(${settings.backgroundBlur}px)`;

    if (settings.backgroundImage) {
      refs.backgroundLayer.style.backgroundImage = `url("${settings.backgroundImage}")`;
    }
    refs.searchEngineButton.textContent = ENGINE_LABELS[settings.searchEngine] || "Bing";

    /* Sidebar collapsed state */
    if (settings.sidebarCollapsed) {
      refs.sidebar.classList.add("collapsed");
    } else {
      refs.sidebar.classList.remove("collapsed");
    }
  }

  /* ── Clock ────────────────────────────────────────────── */

  function updateClock() {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, "0");
    const minutes = String(now.getMinutes()).padStart(2, "0");
    refs.timeText.textContent = `${hours}:${minutes}`;

    const days = ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"];
    const year = now.getFullYear();
    const month = now.getMonth() + 1;
    const day = now.getDate();
    const weekday = days[now.getDay()];
    refs.dateText.textContent = `${year}年${month}月${day}日 ${weekday}`;
  }

  function startClock() {
    updateClock();
    clockTimer = window.setInterval(updateClock, 1000);
  }

  /* ── Greeting ─────────────────────────────────────────── */

  function getGreetingText() {
    const name = config.settings.username || "Friend";
    const langGroup = GREETINGS[greetingIndex % GREETINGS.length];
    const phrase = langGroup.phrases[phraseIndex % langGroup.phrases.length];
    return {
      text: phrase.replace("{name}", name),
      lang: langGroup.lang
    };
  }

  function updateGreeting() {
    const { text, lang } = getGreetingText();
    refs.greetingText.textContent = text;
    refs.greetingText.setAttribute("lang", lang);
  }

  function cycleGreeting() {
    /* Every cycle, advance the phrase; every 2nd cycle advance language */
    phraseIndex += 1;
    if (phraseIndex % 3 === 0) {
      greetingIndex = (greetingIndex + 1) % GREETINGS.length;
    }
    updateGreeting();
  }

  /* ── Display Mode ─────────────────────────────────────── */

  function applyDisplayMode(mode) {
    window.clearInterval(alternateTimer);
    const clockEl = refs.clockDisplay;
    const greetEl = refs.greetingDisplay;

    clockEl.classList.remove("hidden", "fading");
    greetEl.classList.remove("hidden", "fading");

    switch (mode) {
      case "clock":
        greetEl.classList.add("hidden");
        break;
      case "greeting":
        clockEl.classList.add("hidden");
        break;
      case "both":
        break;
      case "alternate":
        /* Show clock first, then alternate */
        greetEl.classList.add("hidden");
        alternateTimer = window.setInterval(() => {
          if (clockEl.classList.contains("hidden")) {
            /* Switch to clock */
            greetEl.classList.add("fading");
            window.setTimeout(() => {
              greetEl.classList.add("hidden");
              greetEl.classList.remove("fading");
              clockEl.classList.remove("hidden", "fading");
            }, 400);
          } else {
            /* Switch to greeting */
            cycleGreeting();
            clockEl.classList.add("fading");
            window.setTimeout(() => {
              clockEl.classList.add("hidden");
              clockEl.classList.remove("fading");
              greetEl.classList.remove("hidden", "fading");
            }, 400);
          }
        }, 8000);
        break;
    }
  }

  /* ── Header Position ──────────────────────────────────── */

  function applyHeaderPosition(pct) {
    if (!refs.newtabShell) return;
    /* pct is 10-90, representing how far down the page the header should appear.
       We calculate padding-top so the header+search area (approx 200px) lands at pct% of the viewport. */
    const viewportH = window.innerHeight;
    const contentH = 200; /* approximate height of header + search */
    const maxPadding = Math.max(0, viewportH - contentH - 60); /* leave 60px for desktop */
    const paddingTop = Math.round(maxPadding * pct / 100);
    refs.newtabShell.style.paddingTop = `${paddingTop}px`;
  }

  /* ── Icon Helpers ─────────────────────────────────────── */

  function createIconElement(site, size) {
    const iconSize = size || site.size || config.settings.defaultIconSize;
    const iconUrl = site.icon || NewtabStorage.faviconFor(site.url);
    if (iconUrl) {
      const img = document.createElement("img");
      img.className = "site-icon";
      img.alt = "";
      img.draggable = false;
      img.src = iconUrl;
      img.style.setProperty("--icon-size", `${iconSize}px`);
      img.onerror = () => { img.replaceWith(createFallbackIcon(site.title, iconSize)); };
      return img;
    }
    return createFallbackIcon(site.title, iconSize);
  }

  function createFallbackIcon(title, size) {
    const fallback = document.createElement("span");
    fallback.className = "fallback-icon";
    fallback.style.setProperty("--icon-size", `${size}px`);
    fallback.textContent = String(title || "?").trim().charAt(0).toUpperCase() || "?";
    return fallback;
  }

  function createFolderIcon(folder) {
    const icon = document.createElement("span");
    icon.className = "folder-icon";
    icon.style.setProperty("--icon-size", `${folder.size || config.settings.defaultIconSize}px`);
    const children = folder.children
      .map((id) => findItem(id))
      .filter((item) => item && item.type === "site")
      .slice(0, 4);
    for (let index = 0; index < 4; index += 1) {
      const cell = document.createElement("span");
      cell.className = "folder-icon-cell";
      const child = children[index];
      const iconUrl = child && (child.icon || NewtabStorage.faviconFor(child.url));
      if (iconUrl) {
        const image = document.createElement("img");
        image.alt = "";
        image.draggable = false;
        image.src = iconUrl;
        cell.appendChild(image);
      }
      icon.appendChild(cell);
    }
    return icon;
  }

  /* ── Desktop Rendering ────────────────────────────────── */

  function renderDesktop() {
    refs.desktop.innerHTML = "";
    refs.desktop.style.setProperty("--grid-size", `${config.settings.gridSize}px`);

    getDesktopItems().forEach((item) => {
      const itemEl = document.createElement("div");
      itemEl.className = "desktop-item";
      itemEl.tabIndex = 0;
      itemEl.dataset.itemId = item.id;
      itemEl.dataset.itemType = item.type;
      itemEl.style.left = `${item.x}px`;
      itemEl.style.top = `${item.y}px`;
      itemEl.style.setProperty("--grid-size", `${config.settings.gridSize}px`);
      itemEl.style.setProperty("--icon-size", `${item.size || config.settings.defaultIconSize}px`);
      itemEl.setAttribute("role", "button");
      itemEl.setAttribute("aria-label", item.type === "folder" ? `打开文件夹 ${item.title}` : `打开 ${item.title}`);

      const iconShell = document.createElement("span");
      iconShell.className = "icon-shell";
      iconShell.appendChild(item.type === "folder" ? createFolderIcon(item) : createIconElement(item));

      const title = document.createElement("span");
      title.className = "item-title";
      title.textContent = item.title;

      if (item.type === "site") {
        const menuButton = document.createElement("button");
        menuButton.className = "item-menu-button";
        menuButton.type = "button";
        menuButton.title = "编辑网站";
        menuButton.setAttribute("aria-label", `编辑 ${item.title}`);
        menuButton.textContent = "⋯";
        menuButton.addEventListener("click", (event) => {
          event.stopPropagation();
          openSiteDialog(item.id);
        });
        itemEl.append(iconShell, title, menuButton);
      } else {
        itemEl.append(iconShell, title);
      }

      itemEl.addEventListener("click", () => {
        if (itemEl.dataset.dragged === "true") return;
        if (item.type === "folder") NewtabFolder.openFolder(item.id);
        else openSite(item);
      });
      itemEl.addEventListener("keydown", (event) => {
        if (event.key !== "Enter" && event.key !== " ") return;
        event.preventDefault();
        if (item.type === "folder") NewtabFolder.openFolder(item.id);
        else openSite(item);
      });

      refs.desktop.appendChild(itemEl);
    });
  }

  function openSite(site) {
    if (!site || !site.url) return;
    window.location.href = NewtabStorage.normalizeUrl(site.url);
  }

  function moveDesktopItem(itemId, x, y) {
    updateConfig((nextConfig) => {
      const item = nextConfig.items.find((candidate) => candidate.id === itemId);
      if (!item) return;
      item.x = x;
      item.y = y;
    });
    renderDesktop();
  }

  function findFreeDesktopPosition(x, y, ignoreIds) {
    if (window.NewtabDrag && refs.desktop) {
      return NewtabDrag.findNearestFreePosition(x, y, ignoreIds || []);
    }
    return { x: Math.max(0, x), y: Math.max(0, y) };
  }

  function getDropDesktopPosition(event) {
    const rect = refs.desktop.getBoundingClientRect();
    const gridSize = config.settings.gridSize;
    const rawX = event.clientX - rect.left - gridSize / 2;
    const rawY = event.clientY - rect.top - gridSize / 2;
    return findFreeDesktopPosition(rawX, rawY);
  }

  /* ── External drop (URL from browser) ─────────────────── */

  function getExternalDropData(dataTransfer) {
    if (!dataTransfer) return null;
    const html = dataTransfer.getData("text/html");
    const uriList = dataTransfer.getData("text/uri-list");
    const plainText = dataTransfer.getData("text/plain");
    let url = "";
    let title = "";

    if (html) {
      const doc = new DOMParser().parseFromString(html, "text/html");
      const anchor = doc.querySelector("a[href]");
      if (anchor) { url = anchor.href; title = (anchor.textContent || "").trim(); }
    }
    if (!url && uriList) {
      url = uriList.split(/\r?\n/).map((line) => line.trim()).find((line) => line && !line.startsWith("#")) || "";
    }
    if (!url && plainText) {
      const match = plainText.match(/https?:\/\/[^\s<>"']+|www\.[^\s<>"']+|[\w-]+(\.[\w-]+)+(:\d+)?(\/[^\s<>"']*)?/i);
      url = match ? match[0] : "";
      const lines = plainText.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
      title = lines.find((line) => line !== url && !looksLikeUrl(line)) || title;
    }
    if (!url || !looksLikeUrl(url)) return null;
    const normalizedUrl = NewtabStorage.normalizeUrl(url);
    const hostname = NewtabStorage.getHostname(normalizedUrl);
    const fallbackTitle = hostname ? hostname.replace(/^www\./i, "") : "新网站";
    return { url: normalizedUrl, title: (title || fallbackTitle).slice(0, 40) };
  }

  function getFolderDropTarget(event) {
    const element = document.elementFromPoint(event.clientX, event.clientY);
    const itemEl = element && element.closest ? element.closest(".desktop-item[data-item-type='folder']") : null;
    return itemEl ? findItem(itemEl.dataset.itemId) : null;
  }

  function addSiteFromExternalDrop(dropData, event) {
    const folder = getFolderDropTarget(event);
    const position = folder ? { x: folder.x, y: folder.y } : getDropDesktopPosition(event);
    const site = {
      id: NewtabStorage.createId("site"),
      type: "site",
      title: dropData.title,
      url: dropData.url,
      icon: "",
      x: position.x,
      y: position.y,
      size: config.settings.defaultIconSize,
      folderId: folder ? folder.id : null
    };
    updateConfig((nextConfig) => {
      nextConfig.items.push(site);
      if (folder) {
        const nextFolder = nextConfig.items.find((item) => item.id === folder.id);
        if (nextFolder && !nextFolder.children.includes(site.id)) nextFolder.children.push(site.id);
      }
    });
    renderDesktop();
    showToast(folder ? `已添加到「${folder.title}」` : "已添加网站快捷方式");
  }

  function onDesktopDragOver(event) {
    const dropData = getExternalDropData(event.dataTransfer);
    if (!dropData) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = "copy";
    refs.desktop.classList.add("external-drop-active");
  }

  function onDesktopDragLeave(event) {
    if (refs.desktop.contains(event.relatedTarget)) return;
    refs.desktop.classList.remove("external-drop-active");
  }

  function onDesktopDrop(event) {
    const dropData = getExternalDropData(event.dataTransfer);
    refs.desktop.classList.remove("external-drop-active");
    if (!dropData) return;
    event.preventDefault();
    addSiteFromExternalDrop(dropData, event);
  }

  function normalizeLayout() {
    if (!window.NewtabDrag) return;
    updateConfig((nextConfig) => { NewtabDrag.normalizeDesktopLayout(nextConfig); });
    renderDesktop();
  }

  /* ── URL detection ────────────────────────────────────── */

  function looksLikeUrl(value) {
    const text = value.trim();
    if (!text || /\s/.test(text)) return false;
    if (/^[a-z][a-z\d+\-.]*:\/\//i.test(text)) return true;
    if (/^localhost(:\d+)?(\/.*)?$/i.test(text)) return true;
    if (/^\d{1,3}(\.\d{1,3}){3}(:\d+)?(\/.*)?$/.test(text)) return true;
    return /^[\w-]+(\.[\w-]+)+(:\d+)?(\/.*)?$/i.test(text);
  }

  function onSearchSubmit(event) {
    event.preventDefault();
    const query = refs.searchInput.value.trim();
    if (!query) return;

    /* Easter egg: "party" triggers sidebar dance */
    if (query.toLowerCase() === "party") {
      triggerPartyMode();
      refs.searchInput.value = "";
      return;
    }

    if (looksLikeUrl(query)) {
      window.location.href = NewtabStorage.normalizeUrl(query);
      return;
    }
    const engine = config.settings.searchEngine;
    const baseUrl = SEARCH_URLS[engine] || SEARCH_URLS.bing;
    window.location.href = `${baseUrl}${encodeURIComponent(query)}`;
  }

  /* ── Site Dialog ──────────────────────────────────────── */

  function openSiteDialog(siteId) {
    const site = siteId ? findItem(siteId) : null;
    pendingSiteIcon = site && site.icon ? site.icon : "";
    refs.siteDialogTitle.textContent = site ? "编辑网站" : "添加网站";
    refs.editingSiteId.value = site ? site.id : "";
    refs.siteTitle.value = site ? site.title : "";
    refs.siteUrl.value = site ? site.url : "";
    refs.siteSize.value = String(site ? site.size : config.settings.defaultIconSize);
    refs.deleteSiteButton.hidden = !site;
    refs.siteIconInput.value = "";
    renderSiteIconPreview(site);
    refs.siteDialog.showModal();
    refs.siteTitle.focus();
  }

  function renderSiteIconPreview(site) {
    refs.siteIconPreview.innerHTML = "";
    const previewSize = Number(refs.siteSize.value) || 56;
    const previewSite = site || {
      title: refs.siteTitle.value || "网站",
      url: refs.siteUrl.value || "",
      icon: pendingSiteIcon,
      size: previewSize
    };
    const icon = createIconElement(
      Object.assign({}, previewSite, { icon: pendingSiteIcon || previewSite.icon || "", size: previewSize }),
      previewSize
    );
    refs.siteIconPreview.appendChild(icon);
  }

  function onSiteFormSubmit(event) {
    event.preventDefault();
    const title = refs.siteTitle.value.trim();
    const url = NewtabStorage.normalizeUrl(refs.siteUrl.value);
    const size = Number(refs.siteSize.value);
    if (!title || !url) return;

    const editingId = refs.editingSiteId.value;
    if (editingId) {
      updateConfig((nextConfig) => {
        const site = nextConfig.items.find((item) => item.id === editingId);
        if (!site) return;
        site.title = title.slice(0, 40);
        site.url = url;
        site.icon = pendingSiteIcon;
        site.size = size;
      });
      showToast("网站已更新");
    } else {
      const position = findFreeDesktopPosition(0, 0);
      const site = {
        id: NewtabStorage.createId("site"),
        type: "site",
        title: title.slice(0, 40),
        url,
        icon: pendingSiteIcon,
        x: position.x,
        y: position.y,
        size,
        folderId: null
      };
      updateConfig((nextConfig) => { nextConfig.items.push(site); });
      showToast("网站已添加");
    }
    refs.siteDialog.close();
    renderDesktop();
  }

  function deleteCurrentSite() {
    const siteId = refs.editingSiteId.value;
    if (!siteId) return;
    if (!window.confirm("确定删除这个网站快捷方式？")) return;
    updateConfig((nextConfig) => {
      nextConfig.items = nextConfig.items.filter((item) => item.id !== siteId);
      nextConfig.items.forEach((item) => {
        if (item.type === "folder") item.children = item.children.filter((childId) => childId !== siteId);
      });
    });
    refs.siteDialog.close();
    renderDesktop();
    showToast("网站已删除");
  }

  async function onSiteIconUpload(event) {
    const file = event.target.files && event.target.files[0];
    if (!file) return;
    try {
      pendingSiteIcon = await NewtabStorage.compressImageFile(file, {
        maxWidth: 256, maxHeight: 256, quality: 0.9, type: "image/png"
      });
      renderSiteIconPreview();
    } catch (error) {
      showToast("图标处理失败");
    } finally {
      event.target.value = "";
    }
  }

  /* ── Toast ────────────────────────────────────────────── */

  function showToast(message) {
    refs.toast.textContent = message;
    refs.toast.classList.add("show");
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => { refs.toast.classList.remove("show"); }, 2200);
  }

  /* ── Sidebar Events ───────────────────────────────────── */

  function onSidebarToggle() {
    const collapsed = !refs.sidebar.classList.contains("collapsed");
    refs.sidebar.classList.toggle("collapsed", collapsed);
    updateConfig((c) => { c.settings.sidebarCollapsed = collapsed; });
  }

  /* ── Easter Eggs ──────────────────────────────────────── */

  /** Konami code detection */
  function onKonamiKeydown(event) {
    if (event.target.closest("input, textarea")) return;
    if (event.code === KONAMI_CODE[konamiIndex]) {
      konamiIndex += 1;
      if (konamiIndex === KONAMI_CODE.length) {
        triggerConfetti();
        konamiIndex = 0;
      }
    } else {
      konamiIndex = event.code === KONAMI_CODE[0] ? 1 : 0;
    }
  }

  /** Rainbow confetti */
  function triggerConfetti() {
    const canvas = refs.confettiCanvas;
    canvas.classList.add("active");
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    const ctx = canvas.getContext("2d");
    const particles = [];
    const colors = ["#ff6b6b", "#ffd93d", "#6bcb77", "#4d96ff", "#ff922b", "#845ef7", "#ff6eb4"];

    for (let i = 0; i < 150; i += 1) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height - canvas.height,
        w: Math.random() * 10 + 4,
        h: Math.random() * 6 + 2,
        color: colors[Math.floor(Math.random() * colors.length)],
        vx: (Math.random() - 0.5) * 4,
        vy: Math.random() * 3 + 2,
        rotation: Math.random() * 360,
        rotSpeed: (Math.random() - 0.5) * 10
      });
    }

    let frame = 0;
    function animate() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.04;
        p.rotation += p.rotSpeed;
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate((p.rotation * Math.PI) / 180);
        ctx.fillStyle = p.color;
        ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
        ctx.restore();
      });
      frame += 1;
      if (frame < 180) {
        requestAnimationFrame(animate);
      } else {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        canvas.classList.remove("active");
      }
    }
    requestAnimationFrame(animate);
    showToast("🎉 你发现了隐藏彩蛋！");
  }

  /** Brand icon click counter */
  function onBrandClick() {
    brandClickCount += 1;
    window.clearTimeout(brandClickTimer);
    brandClickTimer = window.setTimeout(() => { brandClickCount = 0; }, 1500);

    /* Animate the icon */
    if (refs.brandIcon) {
      refs.brandIcon.style.transform = `rotate(${brandClickCount * 60}deg) scale(1.3)`;
      window.setTimeout(() => {
        if (refs.brandIcon) refs.brandIcon.style.transform = "rotate(0deg) scale(1)";
      }, 300);
    }

    if (brandClickCount >= 7) {
      brandClickCount = 0;
      const quote = FUN_QUOTES[Math.floor(Math.random() * FUN_QUOTES.length)];
      showAboutToast("🎲 彩蛋", quote);
    }
  }

  /** Party mode — sidebar buttons dance */
  function triggerPartyMode() {
    const buttons = refs.sidebar.querySelectorAll(".sidebar-btn");
    buttons.forEach((btn, i) => {
      window.setTimeout(() => {
        btn.classList.add("dancing");
        window.setTimeout(() => btn.classList.remove("dancing"), 500);
      }, i * 60);
    });
    showToast("🪩 Party time! 🕺");
  }

  /** About modal-like toast */
  function showAboutToast(title, message) {
    let existing = document.querySelector(".about-toast");
    if (existing) existing.remove();

    const toast = document.createElement("div");
    toast.className = "about-toast";
    toast.innerHTML = `<h3>${title}</h3><p>${message}</p>`;
    document.body.appendChild(toast);

    window.setTimeout(() => toast.classList.add("show"), 20);
    window.setTimeout(() => {
      toast.classList.remove("show");
      window.setTimeout(() => toast.remove(), 300);
    }, 3000);
  }

  /* ── Event Binding ────────────────────────────────────── */

  function bindAppEvents() {
    refs.searchForm.addEventListener("submit", onSearchSubmit);
    refs.searchEngineButton.addEventListener("click", NewtabSettings.cycleSearchEngine);
    refs.siteForm.addEventListener("submit", onSiteFormSubmit);
    refs.cancelSiteButton.addEventListener("click", () => refs.siteDialog.close());
    refs.deleteSiteButton.addEventListener("click", deleteCurrentSite);
    refs.siteIconInput.addEventListener("change", onSiteIconUpload);
    refs.siteTitle.addEventListener("input", () => renderSiteIconPreview());
    refs.siteUrl.addEventListener("input", () => renderSiteIconPreview());
    refs.siteSize.addEventListener("change", () => renderSiteIconPreview());
    refs.desktop.addEventListener("dragover", onDesktopDragOver);
    refs.desktop.addEventListener("dragleave", onDesktopDragLeave);
    refs.desktop.addEventListener("drop", onDesktopDrop);
    window.addEventListener("resize", () => { normalizeLayout(); });

    /* Sidebar events */
    refs.sidebarToggle.addEventListener("click", onSidebarToggle);
    refs.sidebarThemeToggle.addEventListener("click", toggleTheme);
    refs.sidebarSettingsBtn.addEventListener("click", () => NewtabSettings.openPanel());
    refs.sidebarShuffleBg.addEventListener("click", shuffleBackground);
    refs.sidebarAbout.addEventListener("click", () => {
      showAboutToast("💡 关于 Beautiful Tab",
        "Edge 美化新标签页<br>版本 1.1.0<br>让你的每一次浏览都充满美感 ✨<br><br>试试输入 party 搜索框？");
    });

    /* Brand icon click counter */
    if (refs.brandIcon) {
      refs.brandIcon.style.cursor = "pointer";
      refs.brandIcon.addEventListener("click", onBrandClick);
    }

    /* Konami code */
    document.addEventListener("keydown", onKonamiKeydown);

    /* Theme keyboard shortcut Ctrl+Shift+T */
    document.addEventListener("keydown", (event) => {
      if (event.ctrlKey && event.shiftKey && event.code === "KeyT") {
        event.preventDefault();
        toggleTheme();
      }
    });
  }

  /* ── Init ─────────────────────────────────────────────── */

  async function init() {
    refs = getRefs();
    config = await NewtabStorage.loadConfig();

    const appApi = {
      getConfig,
      findItem,
      getDesktopItems,
      updateConfig,
      replaceConfig,
      applySettings,
      renderDesktop,
      createIconElement,
      openSite,
      openSiteDialog,
      moveDesktopItem,
      findFreeDesktopPosition,
      normalizeLayout,
      showToast,
      updateGreeting,
      applyDisplayMode,
      applyHeaderPosition,
      addSiteToFolder: (...args) => NewtabFolder.addSiteToFolder(...args),
      createFolderFromSites: (...args) => NewtabFolder.createFolderFromSites(...args)
    };

    NewtabFolder.init(appApi, refs);
    NewtabDrag.init(appApi, refs.desktop);
    NewtabSettings.init(appApi, refs);
    bindAppEvents();

    /* Apply initial state */
    applyThemeFromSettings();
    applySettings();
    NewtabSettings.applyValues(config.settings);
    applyHeaderPosition(config.settings.headerPosition);
    startClock();
    updateGreeting();
    applyDisplayMode(config.settings.displayMode);
    normalizeLayout();
    renderDesktop();

    /* Author card easter egg */
    if (refs.authorCard) {
      let authorClicks = 0;
      let authorClickTimer = 0;
      refs.authorCard.addEventListener("click", () => {
        authorClicks += 1;
        window.clearTimeout(authorClickTimer);
        authorClickTimer = window.setTimeout(() => { authorClicks = 0; }, 1500);

        if (authorClicks >= 5) {
          authorClicks = 0;
          refs.authorCard.classList.add("spin-cat");
          window.setTimeout(() => refs.authorCard.classList.remove("spin-cat"), 600);
          showToast("🐱 喵～ OhWhy 正在看着你呢！");
        }
      });
    }

    /* Recalculate header position on resize */
    window.addEventListener("resize", () => {
      applyHeaderPosition(config.settings.headerPosition);
    });

    window.setTimeout(() => refs.searchInput.focus(), 60);
  }

  document.addEventListener("DOMContentLoaded", init);
})();
