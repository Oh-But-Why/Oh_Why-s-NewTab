(function () {
  "use strict";

  let api = null;
  let desktopEl = null;
  let dragState = null;

  /** Returns the nearest grid-aligned position for a raw desktop coordinate. */
  function snapToGrid(x, y, gridSize) {
    return {
      x: Math.round(x / gridSize) * gridSize,
      y: Math.round(y / gridSize) * gridSize
    };
  }

  /** Keeps an item inside the visible desktop area. */
  function clampPosition(x, y, gridSize) {
    const maxX = Math.max(0, desktopEl.clientWidth - gridSize);
    const maxY = Math.max(0, desktopEl.clientHeight - gridSize);
    return {
      x: Math.min(Math.max(0, x), maxX),
      y: Math.min(Math.max(0, y), maxY)
    };
  }

  /** Converts arbitrary coordinates into supported final drag coordinates. */
  function finalizePosition(x, y, itemId) {
    const settings = api.getConfig().settings;
    const gridSize = settings.gridSize;
    const clamped = clampPosition(x, y, gridSize);

    if (!settings.autoAlign) {
      return clamped;
    }

    const snapped = snapToGrid(clamped.x, clamped.y, gridSize);
    const reclamped = clampPosition(snapped.x, snapped.y, gridSize);
    return findNearestFreePosition(reclamped.x, reclamped.y, itemId);
  }

  /** Creates an occupancy map for currently visible desktop items. */
  function getOccupiedCells(ignoreIds) {
    const settings = api.getConfig().settings;
    const gridSize = settings.gridSize;
    const ignored = new Set(ignoreIds || []);
    const occupied = new Map();

    api.getDesktopItems().forEach((item) => {
      if (ignored.has(item.id)) return;
      const snapped = snapToGrid(item.x, item.y, gridSize);
      occupied.set(`${snapped.x}:${snapped.y}`, item.id);
    });

    return occupied;
  }

  /** Finds the nearest empty grid cell by expanding outward from a target cell. */
  function findNearestFreePosition(x, y, itemId) {
    const settings = api.getConfig().settings;
    const gridSize = settings.gridSize;
    const ignoreIds = Array.isArray(itemId) ? itemId : [itemId];
    const occupied = getOccupiedCells(ignoreIds);
    const maxX = Math.max(0, Math.floor((desktopEl.clientWidth - gridSize) / gridSize) * gridSize);
    const maxY = Math.max(0, Math.floor((desktopEl.clientHeight - gridSize) / gridSize) * gridSize);
    const start = clampPosition(x, y, gridSize);
    const startX = Math.round(start.x / gridSize) * gridSize;
    const startY = Math.round(start.y / gridSize) * gridSize;
    const maxRadius = Math.ceil(Math.max(maxX, maxY) / gridSize) + 2;

    for (let radius = 0; radius <= maxRadius; radius += 1) {
      const candidates = [];
      for (let dx = -radius; dx <= radius; dx += 1) {
        for (let dy = -radius; dy <= radius; dy += 1) {
          if (Math.max(Math.abs(dx), Math.abs(dy)) !== radius) continue;
          const candidateX = startX + dx * gridSize;
          const candidateY = startY + dy * gridSize;
          if (candidateX < 0 || candidateY < 0 || candidateX > maxX || candidateY > maxY) continue;
          candidates.push({
            x: candidateX,
            y: candidateY,
            distance: Math.hypot(candidateX - startX, candidateY - startY)
          });
        }
      }

      candidates.sort((a, b) => a.distance - b.distance || a.y - b.y || a.x - b.x);
      const free = candidates.find((candidate) => !occupied.has(`${candidate.x}:${candidate.y}`));
      if (free) return { x: free.x, y: free.y };
    }

    return { x: startX, y: startY };
  }

  /** Resolves duplicate desktop grid cells after loading or importing config. */
  function normalizeDesktopLayout(config) {
    if (!desktopEl) return config;
    const settings = config.settings;
    const occupied = new Set();

    config.items
      .filter((item) => item.type === "folder" || (item.type === "site" && !item.folderId))
      .forEach((item) => {
        if (!settings.autoAlign) {
          const clamped = clampPosition(item.x, item.y, settings.gridSize);
          item.x = clamped.x;
          item.y = clamped.y;
          return;
        }

        const snapped = snapToGrid(item.x, item.y, settings.gridSize);
        const clamped = clampPosition(snapped.x, snapped.y, settings.gridSize);
        const key = `${clamped.x}:${clamped.y}`;
        if (!occupied.has(key)) {
          item.x = clamped.x;
          item.y = clamped.y;
          occupied.add(key);
          return;
        }

        const free = findNearestFreePosition(clamped.x, clamped.y, item.id);
        item.x = free.x;
        item.y = free.y;
        occupied.add(`${free.x}:${free.y}`);
      });

    return config;
  }

  /** Returns a desktop item below the drop point, if one exists. */
  function getDropTarget(clientX, clientY, sourceId) {
    const sourceEl = desktopEl.querySelector(`[data-item-id="${CSS.escape(sourceId)}"]`);
    if (sourceEl) sourceEl.style.pointerEvents = "none";
    const element = document.elementFromPoint(clientX, clientY);
    if (sourceEl) sourceEl.style.pointerEvents = "";
    const target = element && element.closest ? element.closest(".desktop-item") : null;
    if (!target || target.dataset.itemId === sourceId) return null;
    return {
      id: target.dataset.itemId,
      type: target.dataset.itemType,
      element: target
    };
  }

  /** Clears visual drop-target state from all desktop items. */
  function clearDropTargets() {
    desktopEl.querySelectorAll(".drop-target").forEach((element) => {
      element.classList.remove("drop-target");
    });
  }

  /** Starts pointer-driven drag tracking for one desktop item. */
  function onPointerDown(event) {
    const itemEl = event.target.closest(".desktop-item");
    if (!itemEl || event.button !== 0) return;
    if (event.target.closest("button, input, select, textarea, a")) return;

    const item = api.findItem(itemEl.dataset.itemId);
    if (!item) return;

    dragState = {
      item,
      itemEl,
      pointerId: event.pointerId,
      startClientX: event.clientX,
      startClientY: event.clientY,
      startX: item.x,
      startY: item.y,
      currentX: item.x,
      currentY: item.y,
      moved: false
    };

    itemEl.setPointerCapture(event.pointerId);
    itemEl.addEventListener("pointermove", onPointerMove);
    itemEl.addEventListener("pointerup", onPointerUp);
    itemEl.addEventListener("pointercancel", onPointerCancel);
  }

  /** Updates item position while dragging and highlights folder/site drop targets. */
  function onPointerMove(event) {
    if (!dragState) return;
    const dx = event.clientX - dragState.startClientX;
    const dy = event.clientY - dragState.startClientY;
    if (!dragState.moved && Math.hypot(dx, dy) < 5) return;

    dragState.moved = true;
    dragState.itemEl.classList.add("dragging");
    const settings = api.getConfig().settings;
    const clamped = clampPosition(dragState.startX + dx, dragState.startY + dy, settings.gridSize);
    dragState.currentX = clamped.x;
    dragState.currentY = clamped.y;
    dragState.itemEl.style.left = `${clamped.x}px`;
    dragState.itemEl.style.top = `${clamped.y}px`;

    clearDropTargets();
    if (dragState.item.type === "site") {
      const target = getDropTarget(event.clientX, event.clientY, dragState.item.id);
      if (target && (target.type === "folder" || target.type === "site")) {
        target.element.classList.add("drop-target");
      }
    }
  }

  /** Completes a drag operation and delegates folder/site drop behavior to the app. */
  function onPointerUp(event) {
    if (!dragState) return;
    const state = dragState;
    const itemEl = state.itemEl;
    const wasMoved = state.moved;

    itemEl.releasePointerCapture(state.pointerId);
    itemEl.removeEventListener("pointermove", onPointerMove);
    itemEl.removeEventListener("pointerup", onPointerUp);
    itemEl.removeEventListener("pointercancel", onPointerCancel);
    itemEl.classList.remove("dragging");
    itemEl.dataset.dragged = wasMoved ? "true" : "false";
    window.setTimeout(() => {
      itemEl.dataset.dragged = "false";
    }, 0);

    clearDropTargets();
    dragState = null;

    if (!wasMoved) return;

    if (state.item.type === "site") {
      const target = getDropTarget(event.clientX, event.clientY, state.item.id);
      if (target && target.type === "folder") {
        api.addSiteToFolder(state.item.id, target.id);
        return;
      }
      if (target && target.type === "site") {
        api.createFolderFromSites(state.item.id, target.id);
        return;
      }
    }

    const finalPosition = finalizePosition(state.currentX, state.currentY, state.item.id);
    api.moveDesktopItem(state.item.id, finalPosition.x, finalPosition.y);
  }

  /** Cancels a drag and restores the current rendered state. */
  function onPointerCancel() {
    if (!dragState) return;
    const itemEl = dragState.itemEl;
    itemEl.removeEventListener("pointermove", onPointerMove);
    itemEl.removeEventListener("pointerup", onPointerUp);
    itemEl.removeEventListener("pointercancel", onPointerCancel);
    itemEl.classList.remove("dragging");
    clearDropTargets();
    dragState = null;
    api.renderDesktop();
  }

  /** Initializes desktop pointer handling. */
  function init(appApi, desktopElement) {
    api = appApi;
    desktopEl = desktopElement;
    desktopEl.addEventListener("pointerdown", onPointerDown);
  }

  window.NewtabDrag = {
    init,
    snapToGrid,
    clampPosition,
    findNearestFreePosition,
    normalizeDesktopLayout
  };
})();
