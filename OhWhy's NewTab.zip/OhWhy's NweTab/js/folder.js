(function () {
  "use strict";

  let api = null;
  let elements = null;
  let activeFolderId = null;

  /** Initializes folder modal controls and keeps them delegated from app state. */
  function init(appApi, refs) {
    api = appApi;
    elements = refs;

    elements.closeFolderButton.addEventListener("click", closeFolder);
    elements.modalBackdrop.addEventListener("click", closeFolder);
    elements.deleteFolderButton.addEventListener("click", () => {
      if (activeFolderId) deleteFolderWithPrompt(activeFolderId);
    });
    elements.folderTitleInput.addEventListener("change", renameActiveFolder);
    elements.folderTitleInput.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        elements.folderTitleInput.blur();
      }
      if (event.key === "Escape") {
        event.preventDefault();
        closeFolder();
      }
    });
  }

  /** Opens the transparent folder panel for a desktop folder item. */
  function openFolder(folderId) {
    const folder = api.findItem(folderId);
    if (!folder || folder.type !== "folder") return;
    activeFolderId = folderId;
    elements.folderTitleInput.value = folder.title;
    renderFolderItems(folder);
    elements.modalBackdrop.hidden = false;
    elements.folderModal.classList.add("open");
    elements.folderModal.setAttribute("aria-hidden", "false");
  }

  /** Closes the folder panel without changing folder contents. */
  function closeFolder() {
    activeFolderId = null;
    elements.folderModal.classList.remove("open");
    elements.folderModal.setAttribute("aria-hidden", "true");
    elements.modalBackdrop.hidden = true;
    elements.folderItems.innerHTML = "";
  }

  /** Renders all child site shortcuts inside the active folder. */
  function renderFolderItems(folder) {
    elements.folderItems.innerHTML = "";
    const children = folder.children
      .map((id) => api.findItem(id))
      .filter((item) => item && item.type === "site");

    if (!children.length) {
      const empty = document.createElement("div");
      empty.className = "folder-empty";
      empty.textContent = "暂无网站";
      elements.folderItems.appendChild(empty);
      return;
    }

    children.forEach((site) => {
      const shortcut = document.createElement("div");
      shortcut.className = "folder-shortcut";
      shortcut.tabIndex = 0;
      shortcut.setAttribute("role", "button");
      shortcut.dataset.itemId = site.id;
      shortcut.setAttribute("aria-label", `打开 ${site.title}`);

      const icon = api.createIconElement(site, 58);
      const title = document.createElement("span");
      title.className = "folder-shortcut-title";
      title.textContent = site.title;

      const removeButton = document.createElement("button");
      removeButton.className = "folder-remove-button";
      removeButton.type = "button";
      removeButton.title = "移出文件夹";
      removeButton.setAttribute("aria-label", `将 ${site.title} 移出文件夹`);
      removeButton.textContent = "↗";

      removeButton.addEventListener("click", (event) => {
        event.stopPropagation();
        removeSiteFromFolder(site.id);
      });
      shortcut.addEventListener("click", () => api.openSite(site));
      shortcut.addEventListener("keydown", (event) => {
        if (event.key !== "Enter" && event.key !== " ") return;
        event.preventDefault();
        api.openSite(site);
      });

      shortcut.append(icon, title, removeButton);
      elements.folderItems.appendChild(shortcut);
    });
  }

  /** Renames the currently open folder after validating non-empty text. */
  function renameActiveFolder() {
    const folder = activeFolderId ? api.findItem(activeFolderId) : null;
    if (!folder) return;
    const title = elements.folderTitleInput.value.trim() || "新文件夹";
    api.updateConfig((config) => {
      const target = config.items.find((item) => item.id === folder.id);
      if (target) target.title = title.slice(0, 40);
    });
    api.renderDesktop();
    api.showToast("文件夹已重命名");
  }

  /** Removes a site id from every folder to avoid duplicate containment. */
  function detachSiteFromFolders(config, siteId) {
    config.items.forEach((item) => {
      if (item.type !== "folder") return;
      item.children = item.children.filter((childId) => childId !== siteId);
    });
  }

  /** Adds a desktop site shortcut to an existing folder. */
  function addSiteToFolder(siteId, folderId) {
    const site = api.findItem(siteId);
    const folder = api.findItem(folderId);
    if (!site || site.type !== "site" || !folder || folder.type !== "folder") return;

    api.updateConfig((config) => {
      const nextSite = config.items.find((item) => item.id === siteId);
      const nextFolder = config.items.find((item) => item.id === folderId);
      if (!nextSite || !nextFolder) return;
      detachSiteFromFolders(config, siteId);
      nextSite.folderId = folderId;
      if (!nextFolder.children.includes(siteId)) nextFolder.children.push(siteId);
    });

    api.renderDesktop();
    api.showToast(`已加入「${folder.title}」`);
  }

  /** Creates a folder when one site is dropped onto another site. */
  function createFolderFromSites(sourceSiteId, targetSiteId) {
    if (sourceSiteId === targetSiteId) return;
    const source = api.findItem(sourceSiteId);
    const target = api.findItem(targetSiteId);
    if (!source || !target || source.type !== "site" || target.type !== "site") return;

    const folderId = NewtabStorage.createId("folder");
    api.updateConfig((config) => {
      const nextSource = config.items.find((item) => item.id === sourceSiteId);
      const nextTarget = config.items.find((item) => item.id === targetSiteId);
      if (!nextSource || !nextTarget) return;

      detachSiteFromFolders(config, sourceSiteId);
      detachSiteFromFolders(config, targetSiteId);

      nextSource.folderId = folderId;
      nextTarget.folderId = folderId;
      const folder = {
        id: folderId,
        type: "folder",
        title: "新文件夹",
        x: nextTarget.x,
        y: nextTarget.y,
        size: config.settings.defaultIconSize,
        children: [targetSiteId, sourceSiteId]
      };
      config.items.push(folder);
    });

    api.renderDesktop();
    openFolder(folderId);
    api.showToast("已创建新文件夹");
  }

  /** Creates a blank desktop folder from the settings panel. */
  function createFolder(title) {
    const config = api.getConfig();
    const position = api.findFreeDesktopPosition(0, 0);
    const folder = {
      id: NewtabStorage.createId("folder"),
      type: "folder",
      title: (title || "新文件夹").slice(0, 40),
      x: position.x,
      y: position.y,
      size: config.settings.defaultIconSize,
      children: []
    };

    api.updateConfig((nextConfig) => {
      nextConfig.items.push(folder);
    });
    api.renderDesktop();
    api.showToast("已创建文件夹");
  }

  /** Moves a child site out of a folder and back to the desktop grid. */
  function removeSiteFromFolder(siteId) {
    const site = api.findItem(siteId);
    if (!site || !activeFolderId) return;
    const folder = api.findItem(activeFolderId);
    const baseX = folder ? folder.x : 0;
    const baseY = folder ? folder.y : 0;
    const position = api.findFreeDesktopPosition(baseX, baseY, [siteId]);

    api.updateConfig((config) => {
      const nextSite = config.items.find((item) => item.id === siteId);
      if (!nextSite) return;
      detachSiteFromFolders(config, siteId);
      nextSite.folderId = null;
      nextSite.x = position.x;
      nextSite.y = position.y;
    });

    const nextFolder = api.findItem(activeFolderId);
    if (nextFolder) renderFolderItems(nextFolder);
    api.renderDesktop();
    api.showToast("已移出文件夹");
  }

  /** Deletes a folder after asking whether children should be deleted or restored. */
  function deleteFolderWithPrompt(folderId) {
    const folder = api.findItem(folderId);
    if (!folder || folder.type !== "folder") return;

    const deleteChildren = window.confirm(
      "删除文件夹时是否同时删除里面的网站？\n\n确定：删除文件夹和里面的网站\n取消：只删除文件夹，并把网站移回桌面"
    );

    api.updateConfig((config) => {
      const targetFolder = config.items.find((item) => item.id === folderId);
      if (!targetFolder) return;
      const childIds = new Set(targetFolder.children);

      if (deleteChildren) {
        config.items = config.items.filter((item) => item.id !== folderId && !childIds.has(item.id));
        return;
      }

      let offset = 0;
      targetFolder.children.forEach((childId) => {
        const site = config.items.find((item) => item.id === childId);
        if (!site) return;
        site.folderId = null;
        const position = api.findFreeDesktopPosition(
          targetFolder.x + offset * config.settings.gridSize,
          targetFolder.y,
          [childId, folderId]
        );
        site.x = position.x;
        site.y = position.y;
        offset += 1;
      });
      config.items = config.items.filter((item) => item.id !== folderId);
    });

    closeFolder();
    api.renderDesktop();
    api.showToast("文件夹已删除");
  }

  window.NewtabFolder = {
    init,
    openFolder,
    closeFolder,
    addSiteToFolder,
    createFolderFromSites,
    createFolder,
    removeSiteFromFolder,
    deleteFolderWithPrompt
  };
})();
