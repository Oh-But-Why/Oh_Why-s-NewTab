# Edge Beautiful Newtab

一个本地优先的 Microsoft Edge 自定义新标签页扩展。第一版使用 Manifest V3、HTML、CSS 和原生 JavaScript，不依赖 React、构建工具或后端服务。

## 功能

- 接管 Edge 新标签页，显示自定义桌面式导航页面。
- 顶部搜索框支持 Bing、Google、Baidu，并自动识别网址。
- 支持上传本地背景图，设置 cover、contain、repeat、模糊度和亮度。
- 支持添加、编辑、删除网站快捷方式，自定义图标和图标大小。
- 网站图标支持桌面式拖拽、网格吸附、边界限制和位置保存。
- 支持创建手机桌面式文件夹，拖入网站，拖网站到网站自动创建文件夹。
- 文件夹打开后使用透明毛玻璃弹窗，内部网站可打开或移回桌面。
- 支持导出和导入配置 JSON。

## 在 Edge 中加载

1. 打开 `edge://extensions/`
2. 开启“开发人员模式”
3. 点击“加载解压缩的扩展”
4. 选择本项目文件夹：`edge-beautiful-newtab`
5. 打开新标签页测试

## 数据保存

所有配置保存在浏览器本地 `chrome.storage.local` 中，主键为：

```text
beautifulNewtabConfig
```

配置结构：

```json
{
  "settings": {
    "backgroundImage": "",
    "backgroundFit": "cover",
    "backgroundBlur": 0,
    "backgroundBrightness": 1,
    "defaultIconSize": 64,
    "autoAlign": true,
    "gridSize": 96,
    "searchEngine": "bing"
  },
  "items": []
}
```

上传的背景图和自定义图标会先压缩为 data URL 后保存。扩展声明了 `unlimitedStorage`，以降低大图片保存失败的概率。

## 文件结构

```text
edge-beautiful-newtab/
├─ manifest.json
├─ newtab.html
├─ css/style.css
├─ js/app.js
├─ js/storage.js
├─ js/drag.js
├─ js/folder.js
├─ js/settings.js
├─ assets/default-icons/
└─ README.md
```

## 使用提示

- 点击网站图标会在当前标签页打开网站。
- 点击网站图标右上角的 `...` 可以编辑或删除网站。
- 从地址栏、书签栏或网页里拖入一个网站链接到桌面，可以直接添加快捷方式。
- 把外部网站链接拖到文件夹图标上，可以直接添加到该文件夹。
- 拖动网站到文件夹图标上，会把网站加入文件夹。
- 拖动一个网站到另一个网站上，会自动创建新文件夹。
- 删除文件夹时会询问：删除文件夹和里面的网站，或只删除文件夹并把网站移回桌面。
